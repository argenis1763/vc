<?php $this->beginContent('//layouts/main'); ?>
<div class="row-fluid">
	<div class="span12">
		<div class="main">
			<?php echo $content; ?>
		</div>	
	</div><!-- content -->
</div>
<?php $this->endContent(); ?>
